# Trading Bot — Binance Futures Testnet (USDT-M)

A small, structured Python CLI application for placing MARKET, LIMIT, and
STOP_LIMIT orders on Binance Futures Testnet, with input validation,
structured logging, and clean error handling.

## Project Structure

```
trading_bot/
  bot/
    __init__.py
    client.py         # Signed REST calls to Binance Futures Testnet
    orders.py          # Order placement logic (validation -> API -> result)
    validators.py       # Input validation rules
    logging_config.py   # Rotating file + console logging setup
  scripts/
    generate_sample_logs.py   # Produces sample logs without live credentials
  tests/
    test_validators.py
  logs/
    trading_bot.log     # Created at runtime; sample included in repo
  cli.py                # CLI entry point
  requirements.txt
  .env.example
  README.md
```

The code is layered on purpose: `client.py` only knows how to talk to
Binance's HTTP API; `validators.py` only knows validation rules; `orders.py`
composes the two and returns a plain, easy-to-print result object; `cli.py`
is the only place that touches `argparse` or `print`. This keeps each piece
testable and reusable (e.g. `orders.place_order` could be called from a
future web UI with no changes).

## Setup

### 1. Get Binance Futures Testnet credentials

1. Go to https://testnet.binancefuture.com and log in (GitHub login).
2. Once logged in, go to **API Key** in the testnet dashboard and generate
   a key/secret pair.
3. The testnet gives you demo USDT futures balance automatically — no real
   funds are involved.

### 2. Install dependencies

Requires Python 3.9+.

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure credentials

Copy `.env.example` to `.env` and fill in your testnet keys:

```bash
cp .env.example .env
```

```
BINANCE_API_KEY=your_testnet_api_key_here
BINANCE_API_SECRET=your_testnet_api_secret_here
```

The CLI loads `.env` automatically via `python-dotenv`. You can also export
these as real environment variables instead of using a `.env` file.

## How to Run

### Place a MARKET order

```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
```

### Place a LIMIT order

```bash
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 65000
```

### Place a STOP_LIMIT order (bonus order type)

```bash
python cli.py --symbol BTCUSDT --side BUY --type STOP_LIMIT \
  --quantity 0.01 --price 64000 --stop-price 64500
```

### Sample output

```
--- Order Request ---
  symbol: BTCUSDT
  side: BUY
  order_type: MARKET
  quantity: 0.01
--- Order Response ---
  orderId:     5001234567
  status:      FILLED
  executedQty: 0.010
  avgPrice:    65210.50
RESULT: SUCCESS
```

On failure (bad input, rejected order, or network issue), the same
structure is printed with a `--- Error ---` section and `RESULT: FAILED`,
and the process exits with a non-zero status code.

### CLI options

| Flag           | Required          | Notes                                  |
|----------------|--------------------|-----------------------------------------|
| `--symbol`     | yes                | e.g. `BTCUSDT`                          |
| `--side`       | yes                | `BUY` or `SELL`                         |
| `--type`       | yes                | `MARKET`, `LIMIT`, or `STOP_LIMIT`      |
| `--quantity`   | yes                | must be > 0                             |
| `--price`      | for LIMIT/STOP_LIMIT | order price, must be > 0             |
| `--stop-price` | for STOP_LIMIT     | trigger price, must be > 0              |
| `--log-level`  | no                 | console verbosity (file always logs DEBUG) |

## Logging

Every run appends to `logs/trading_bot.log` (rotated at 2MB, 5 backups
kept). Each entry includes a timestamp, level, and message. Full request
parameters and raw API responses are logged at `DEBUG` level to the file
(the API signature is redacted); the console only shows `INFO`+ by default
so day-to-day usage isn't noisy.

`logs/trading_bot.log` in this repo already contains one MARKET and one
LIMIT order (generated via `scripts/generate_sample_logs.py`, which mocks
the HTTP layer so the sample doesn't require live credentials). Running
`cli.py` against the real testnet produces log entries in the exact same
format.

## Error Handling

- **Invalid input** (bad symbol, non-numeric quantity, missing price for a
  LIMIT order, etc.) is caught by `bot/validators.py` before any network
  call is made, and reported clearly without a stack trace.
- **API errors** (e.g. insufficient testnet balance, invalid symbol,
  rejected order) are caught around the HTTP call, logged with the
  Binance error code/message, and surfaced to the user as
  `API error (<code>): <message>`.
- **Network failures** (timeouts, DNS issues, connection refused) are
  caught separately and reported as `Network error: <details>`.
- Any other unexpected exception is logged with a full traceback
  (`logger.exception`) and reported generically, so the CLI never crashes
  with a raw traceback in the user's face.

## Testing

Unit tests cover the validation layer:

```bash
python -m pytest tests/ -v
```

## Assumptions

- Binance Futures Testnet base URL is fixed to
  `https://testnet.binancefuture.com` and USDT-M futures endpoints
  (`/fapi/...`) are used throughout, per the task spec.
- LIMIT and STOP_LIMIT orders are placed with `timeInForce=GTC`
  (Good-Til-Cancelled), which is the most common default and not specified
  otherwise in the task.
- STOP_LIMIT is implemented as the bonus third order type, mapped to
  Binance's `STOP` order type (their stop-limit order).
- The account/leverage/margin type on the testnet account is assumed to be
  pre-configured by the user before running the bot; this bot only places
  orders and does not change account settings.
- `python-binance` was intentionally not used in favor of direct signed
  REST calls via `requests`, to keep the signing/request logic fully
  visible and avoid coupling to a third-party library's testnet support.

## Bonus Implemented

- **Third order type**: STOP_LIMIT (`--type STOP_LIMIT`), mapped to
  Binance's `STOP` order with both `price` and `stop-price`.
