"""
Generates sample log entries for one MARKET and one LIMIT order by mocking
the Binance HTTP layer, so reviewers can see log format/content without
needing live testnet credentials. Real usage (via cli.py) hits the actual
https://testnet.binancefuture.com API and produces the same log structure.
"""

import os
import sys
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.client import FuturesTestnetClient
from bot.logging_config import setup_logging
from bot.orders import place_order

setup_logging("INFO")

client = FuturesTestnetClient(api_key="demo_key", api_secret="demo_secret")


def fake_response(order_type, symbol, side, qty, price):
    resp = MagicMock()
    resp.ok = True
    resp.status_code = 200
    body = {
        "orderId": 5001234567 if order_type == "MARKET" else 5001234568,
        "symbol": symbol,
        "status": "FILLED" if order_type == "MARKET" else "NEW",
        "side": side,
        "type": order_type,
        "executedQty": qty if order_type == "MARKET" else "0.000",
        "origQty": str(qty),
        "avgPrice": "65210.50" if order_type == "MARKET" else "0.00",
        "price": str(price) if price else "0.00",
    }
    resp.json.return_value = body
    resp.text = str(body)
    return resp


with patch("requests.Session.request") as mock_request:
    mock_request.return_value = fake_response("MARKET", "BTCUSDT", "BUY", "0.010", None)
    result = place_order(client, "BTCUSDT", "BUY", "MARKET", 0.01)
    print(result.summary())
    print()

    mock_request.return_value = fake_response("LIMIT", "BTCUSDT", "SELL", "0.010", 65000)
    result = place_order(client, "BTCUSDT", "SELL", "LIMIT", 0.01, price=65000)
    print(result.summary())

print("\nSample logs written to logs/trading_bot.log")
