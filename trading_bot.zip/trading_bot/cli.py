#!/usr/bin/env python3
"""
CLI entry point for the Binance Futures Testnet trading bot.

Examples:
    python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

    python cli.py --symbol BTCUSDT --side SELL --type LIMIT \\
        --quantity 0.01 --price 65000

    python cli.py --symbol BTCUSDT --side BUY --type STOP_LIMIT \\
        --quantity 0.01 --price 64000 --stop-price 64500

Credentials are read from environment variables BINANCE_API_KEY and
BINANCE_API_SECRET (a .env file is also supported, see README.md).
"""

import argparse
import os
import sys

from dotenv import load_dotenv

from bot.client import FuturesTestnetClient, BinanceAPIError, BinanceNetworkError
from bot.logging_config import setup_logging
from bot.orders import place_order


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading-bot",
        description="Place MARKET / LIMIT / STOP_LIMIT orders on Binance Futures Testnet (USDT-M).",
    )
    parser.add_argument("--symbol", required=True, help="Trading pair, e.g. BTCUSDT")
    parser.add_argument("--side", required=True, choices=["BUY", "SELL", "buy", "sell"],
                         help="Order side")
    parser.add_argument("--type", required=True, dest="order_type",
                         choices=["MARKET", "LIMIT", "STOP_LIMIT", "market", "limit", "stop_limit"],
                         help="Order type")
    parser.add_argument("--quantity", required=True, type=float, help="Order quantity")
    parser.add_argument("--price", type=float, default=None,
                         help="Order price (required for LIMIT and STOP_LIMIT)")
    parser.add_argument("--stop-price", type=float, default=None,
                         help="Stop trigger price (required for STOP_LIMIT)")
    parser.add_argument("--log-level", default="INFO",
                         choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                         help="Console log verbosity (file log always captures DEBUG)")
    return parser


def get_credentials():
    load_dotenv()
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")
    if not api_key or not api_secret:
        print(
            "ERROR: Missing credentials. Set BINANCE_API_KEY and BINANCE_API_SECRET "
            "as environment variables or in a .env file (see README.md).",
            file=sys.stderr,
        )
        sys.exit(1)
    return api_key, api_secret


def main():
    parser = build_parser()
    args = parser.parse_args()

    logger = setup_logging(args.log_level)
    api_key, api_secret = get_credentials()

    try:
        client = FuturesTestnetClient(api_key=api_key, api_secret=api_secret)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)

    result = place_order(
        client=client,
        symbol=args.symbol,
        side=args.side,
        order_type=args.order_type,
        quantity=args.quantity,
        price=args.price,
        stop_price=args.stop_price,
    )

    print(result.summary())

    if not result.success:
        sys.exit(1)


if __name__ == "__main__":
    main()
