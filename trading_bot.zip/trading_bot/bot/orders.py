"""
Order placement logic: ties together validation, the API client, and
presentation of results. Kept separate from the CLI so it can be reused
by other entry points (tests, a future UI, etc.).
"""

import logging

from bot.client import BinanceAPIError, BinanceNetworkError, FuturesTestnetClient
from bot.validators import ValidationError, validate_order_params

logger = logging.getLogger("trading_bot")


class OrderResult:
    """Simple container for a normalized order outcome."""

    def __init__(self, success: bool, request: dict, response: dict = None, error: str = None):
        self.success = success
        self.request = request
        self.response = response or {}
        self.error = error

    def summary(self) -> str:
        lines = ["--- Order Request ---"]
        for key, value in self.request.items():
            if value is not None:
                lines.append(f"  {key}: {value}")

        if self.success:
            lines.append("--- Order Response ---")
            lines.append(f"  orderId:     {self.response.get('orderId')}")
            lines.append(f"  status:      {self.response.get('status')}")
            lines.append(f"  executedQty: {self.response.get('executedQty')}")
            avg_price = self.response.get("avgPrice")
            if avg_price is not None:
                lines.append(f"  avgPrice:    {avg_price}")
            lines.append("RESULT: SUCCESS")
        else:
            lines.append("--- Error ---")
            lines.append(f"  {self.error}")
            lines.append("RESULT: FAILED")

        return "\n".join(lines)


def place_order(
    client: FuturesTestnetClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity,
    price=None,
    stop_price=None,
) -> OrderResult:
    """
    Validate inputs, submit the order to Binance Futures Testnet, and
    return a normalized OrderResult regardless of success or failure
    (callers should check `.success` rather than relying on exceptions).
    """
    try:
        params = validate_order_params(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price,
        )
    except ValidationError as exc:
        logger.warning("Validation failed: %s", exc)
        return OrderResult(success=False, request={"symbol": symbol, "side": side,
                                                     "order_type": order_type, "quantity": quantity,
                                                     "price": price, "stop_price": stop_price},
                            error=f"Validation error: {exc}")

    request_summary = {
        "symbol": params["symbol"],
        "side": params["side"],
        "order_type": params["order_type"],
        "quantity": params["quantity"],
        "price": params["price"],
        "stop_price": params["stop_price"],
    }

    try:
        response = client.place_order(
            symbol=params["symbol"],
            side=params["side"],
            order_type=params["order_type"],
            quantity=params["quantity"],
            price=params["price"],
            stop_price=params["stop_price"],
        )
        logger.info(
            "Order placed successfully | orderId=%s status=%s",
            response.get("orderId"), response.get("status"),
        )
        return OrderResult(success=True, request=request_summary, response=response)

    except BinanceAPIError as exc:
        logger.error("Order rejected by API: %s", exc)
        msg = exc.payload.get("msg", str(exc.payload)) if isinstance(exc.payload, dict) else str(exc.payload)
        return OrderResult(success=False, request=request_summary,
                            error=f"API error ({exc.status_code}): {msg}")

    except BinanceNetworkError as exc:
        logger.error("Network error while placing order: %s", exc)
        return OrderResult(success=False, request=request_summary,
                            error=f"Network error: {exc}")

    except Exception as exc:  # noqa: BLE001 - final safety net, always logged
        logger.exception("Unexpected error while placing order")
        return OrderResult(success=False, request=request_summary,
                            error=f"Unexpected error: {exc}")
