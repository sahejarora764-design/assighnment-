"""
Thin wrapper around the Binance Futures Testnet REST API.

Implemented with plain `requests` calls (rather than python-binance) so the
signing logic is fully visible and there's no dependency on a third-party
library matching the exact testnet behavior. Every request/response pair is
logged for auditability.
"""

import hashlib
import hmac
import logging
import time
from urllib.parse import urlencode

import requests

logger = logging.getLogger("trading_bot")

BASE_URL = "https://testnet.binancefuture.com"


class BinanceAPIError(Exception):
    """Raised when the Binance API returns an error response."""

    def __init__(self, status_code, payload):
        self.status_code = status_code
        self.payload = payload
        super().__init__(f"Binance API error [{status_code}]: {payload}")


class BinanceNetworkError(Exception):
    """Raised when the request could not reach Binance at all."""


class FuturesTestnetClient:
    """
    Minimal client for placing orders on Binance USDT-M Futures Testnet.

    Only the endpoints needed by this bot are implemented:
      - POST /fapi/v1/order   (place order)
      - GET  /fapi/v2/account (connectivity / credential check)
    """

    def __init__(self, api_key: str, api_secret: str, base_url: str = BASE_URL, timeout: int = 10):
        if not api_key or not api_secret:
            raise ValueError("api_key and api_secret must be provided.")
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"X-MBX-APIKEY": self.api_key})

    # -- internal helpers ---------------------------------------------------

    def _sign(self, params: dict) -> dict:
        params = dict(params)
        params["timestamp"] = int(time.time() * 1000)
        params["recvWindow"] = params.get("recvWindow", 5000)
        query_string = urlencode(params, doseq=True)
        signature = hmac.new(
            self.api_secret.encode("utf-8"), query_string.encode("utf-8"), hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def _request(self, method: str, path: str, params: dict, signed: bool = True) -> dict:
        url = f"{self.base_url}{path}"
        request_params = self._sign(params) if signed else params

        logger.debug("REQUEST %s %s | params=%s", method, url, _redact(request_params))

        try:
            response = self.session.request(
                method, url, params=request_params, timeout=self.timeout
            )
        except requests.exceptions.RequestException as exc:
            logger.error("NETWORK ERROR %s %s | %s", method, url, exc)
            raise BinanceNetworkError(str(exc)) from exc

        logger.debug(
            "RESPONSE %s %s | status=%s | body=%s",
            method, url, response.status_code, response.text,
        )

        try:
            payload = response.json()
        except ValueError:
            payload = {"raw": response.text}

        if not response.ok:
            logger.error(
                "API ERROR %s %s | status=%s | body=%s",
                method, url, response.status_code, payload,
            )
            raise BinanceAPIError(response.status_code, payload)

        return payload

    # -- public API -----------------------------------------------------------

    def check_connectivity(self) -> dict:
        """Verify API credentials and connectivity via the account endpoint."""
        return self._request("GET", "/fapi/v2/account", {})

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: float = None,
        stop_price: float = None,
        time_in_force: str = "GTC",
    ) -> dict:
        """
        Place an order on Futures Testnet.

        order_type: MARKET | LIMIT | STOP_LIMIT (mapped to Binance's STOP)
        """
        params = {
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
        }

        if order_type == "MARKET":
            params["type"] = "MARKET"
        elif order_type == "LIMIT":
            params["type"] = "LIMIT"
            params["price"] = price
            params["timeInForce"] = time_in_force
        elif order_type == "STOP_LIMIT":
            # Binance Futures uses "STOP" for a stop-limit order
            params["type"] = "STOP"
            params["price"] = price
            params["stopPrice"] = stop_price
            params["timeInForce"] = time_in_force
        else:
            raise ValueError(f"Unsupported order_type: {order_type}")

        logger.info(
            "Placing order | symbol=%s side=%s type=%s qty=%s price=%s stopPrice=%s",
            symbol, side, order_type, quantity, price, stop_price,
        )

        return self._request("POST", "/fapi/v1/order", params)


def _redact(params: dict) -> dict:
    """Never write the signature or key material to logs in full."""
    redacted = dict(params)
    if "signature" in redacted:
        redacted["signature"] = redacted["signature"][:8] + "...redacted"
    return redacted
