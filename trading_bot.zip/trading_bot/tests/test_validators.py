"""Unit tests for bot.validators — run with: python -m pytest tests/"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from bot.validators import ValidationError, validate_order_params


def test_valid_market_order():
    params = validate_order_params("btcusdt", "buy", "market", 0.01)
    assert params["symbol"] == "BTCUSDT"
    assert params["side"] == "BUY"
    assert params["order_type"] == "MARKET"
    assert params["price"] is None


def test_valid_limit_order():
    params = validate_order_params("BTCUSDT", "SELL", "LIMIT", 0.01, price=65000)
    assert params["price"] == 65000.0


def test_limit_order_requires_price():
    with pytest.raises(ValidationError):
        validate_order_params("BTCUSDT", "SELL", "LIMIT", 0.01)


def test_invalid_symbol():
    with pytest.raises(ValidationError):
        validate_order_params("bt", "BUY", "MARKET", 0.01)


def test_invalid_side():
    with pytest.raises(ValidationError):
        validate_order_params("BTCUSDT", "HOLD", "MARKET", 0.01)


def test_invalid_order_type():
    with pytest.raises(ValidationError):
        validate_order_params("BTCUSDT", "BUY", "ICEBERG", 0.01)


def test_negative_quantity():
    with pytest.raises(ValidationError):
        validate_order_params("BTCUSDT", "BUY", "MARKET", -1)


def test_zero_price():
    with pytest.raises(ValidationError):
        validate_order_params("BTCUSDT", "BUY", "LIMIT", 0.01, price=0)


def test_stop_limit_requires_stop_price():
    with pytest.raises(ValidationError):
        validate_order_params("BTCUSDT", "BUY", "STOP_LIMIT", 0.01, price=64000)


def test_valid_stop_limit_order():
    params = validate_order_params(
        "BTCUSDT", "BUY", "STOP_LIMIT", 0.01, price=64000, stop_price=64500
    )
    assert params["stop_price"] == 64500.0
